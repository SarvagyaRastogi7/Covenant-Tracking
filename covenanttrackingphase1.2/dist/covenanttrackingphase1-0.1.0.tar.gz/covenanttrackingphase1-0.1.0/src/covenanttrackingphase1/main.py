#!/usr/bin/env python
import json
import sys
import warnings
from datetime import datetime
from pathlib import Path

from covenanttrackingphase1.crew import Covenanttrackingphase1

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

_PACKAGE_ROOT = Path(__file__).resolve().parent
_DEFAULT_WORKBOOK = _PACKAGE_ROOT / "sample_input.xlsx"


def _default_inputs() -> dict[str, str]:
    return {
        "covenant_workbook_path": str(_DEFAULT_WORKBOOK),
        "reporting_period": "Q4 FY2025-26",
        "borrower_label": "ABC123 / FAC456 facility",
        "current_year": str(datetime.now().year),
    }


def run():
    """Run the covenant tracking crew."""
    inputs = _default_inputs()
    try:
        Covenanttrackingphase1().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}") from e


def train():
    """Train the crew for a given number of iterations."""
    inputs = _default_inputs()
    try:
        Covenanttrackingphase1().crew().train(
            n_iterations=int(sys.argv[1]),
            filename=sys.argv[2],
            inputs=inputs,
        )
    except Exception as e:
        raise Exception(f"An error occurred while training the crew: {e}") from e


def replay():
    """Replay the crew execution from a specific task."""
    try:
        Covenanttrackingphase1().crew().replay(task_id=sys.argv[1])
    except Exception as e:
        raise Exception(f"An error occurred while replaying the crew: {e}") from e


def test():
    """Test the crew execution and return the results."""
    inputs = _default_inputs()
    try:
        Covenanttrackingphase1().crew().test(
            n_iterations=int(sys.argv[1]),
            eval_llm=sys.argv[2],
            inputs=inputs,
        )
    except Exception as e:
        raise Exception(f"An error occurred while testing the crew: {e}") from e


def run_with_trigger():
    """Run the crew with trigger payload (merges into kickoff inputs)."""
    if len(sys.argv) < 2:
        raise Exception("No trigger payload provided. Please provide JSON payload as argument.")

    try:
        trigger_payload = json.loads(sys.argv[1])
    except json.JSONDecodeError as e:
        raise Exception("Invalid JSON payload provided as argument") from e

    inputs = _default_inputs()
    inputs["crewai_trigger_payload"] = trigger_payload
    if isinstance(trigger_payload, dict):
        for key in (
            "covenant_workbook_path",
            "reporting_period",
            "borrower_label",
            "current_year",
        ):
            if key in trigger_payload and trigger_payload[key]:
                inputs[key] = str(trigger_payload[key])

    try:
        return Covenanttrackingphase1().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew with trigger: {e}") from e
